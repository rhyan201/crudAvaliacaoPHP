<?php

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexao.php';

// Padrao de resposta do projeto: status / mensagem / data
function responder($status, $mensagem, $data = null)
{
    echo json_encode([
        'status'   => $status,
        'mensagem' => $mensagem,
        'data'     => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Validacao dos dados recebidos do usuario
function validarDados($nome, $email, $tipo, $telefone)
{
    if (mb_strlen($nome) < 3 || mb_strlen($nome) > 100) {
        return 'O nome deve ter entre 3 e 100 caracteres.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) {
        return 'E-mail inválido.';
    }
    if (!in_array($tipo, ['cliente', 'vendedor'], true)) {
        return 'Tipo de conta inválido.';
    }
    if ($telefone !== null && !preg_match('/^[0-9()+\-\s]{8,20}$/', $telefone)) {
        return 'Telefone inválido.';
    }
    return null;
}

// Verifica se o e-mail ja esta em uso por outro usuario (prepared statement)
function emailEmUso($conexao, $email, $ignorarId = 0)
{
    $stmt = $conexao->prepare('SELECT id_usuario FROM usuario WHERE email = ? AND id_usuario <> ?');
    $stmt->bind_param('si', $email, $ignorarId);
    $stmt->execute();
    $stmt->store_result();
    $existe = $stmt->num_rows > 0;
    $stmt->close();
    return $existe;
}

try {
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        $acao = $_GET['acao'] ?? 'listar';

        if ($acao === 'listar') {
            $stmt = $conexao->prepare(
                'SELECT id_usuario, nome, email, telefone, tipo, ativo, data_cadastro
                 FROM usuario ORDER BY nome'
            );
            $stmt->execute();
            $lista = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            responder('ok', 'Consulta efetuada.', $lista);
        }

        if ($acao === 'perfil') {
            $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) {
                responder('erro', 'ID inválido.');
            }

            $stmt = $conexao->prepare(
                'SELECT id_usuario, nome, email, telefone, tipo, ativo, data_cadastro
                 FROM usuario WHERE id_usuario = ?'
            );
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $perfil = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$perfil) {
                responder('erro', 'Usuário não encontrado.');
            }
            responder('ok', 'Perfil carregado.', $perfil);
        }

        responder('erro', 'Ação GET inválida.');
    }

    if ($metodo === 'POST') {
        $acao = $_POST['acao'] ?? '';

        // ---- CREATE ----
        if ($acao === 'criar') {
            $nome     = trim($_POST['nome'] ?? '');
            $email    = strtolower(trim($_POST['email'] ?? ''));
            $telefone = trim($_POST['telefone'] ?? '') ?: null;
            $tipo     = $_POST['tipo'] ?? '';
            $senha    = $_POST['senha'] ?? '';

            if ($erro = validarDados($nome, $email, $tipo, $telefone)) {
                responder('erro', $erro);
            }
            if (strlen($senha) < 6) {
                responder('erro', 'A senha deve ter no mínimo 6 caracteres.');
            }
            if (emailEmUso($conexao, $email)) {
                responder('erro', 'Este e-mail já está cadastrado.');
            }

            $hash = password_hash($senha, PASSWORD_DEFAULT);

            $stmt = $conexao->prepare(
                'INSERT INTO usuario (nome, email, senha, tipo, telefone) VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->bind_param('sssss', $nome, $email, $hash, $tipo, $telefone);
            $stmt->execute();
            $novoId = $conexao->insert_id;
            $stmt->close();

            responder('ok', 'Usuário cadastrado com sucesso.', ['id_usuario' => $novoId]);
        }

        if ($acao === 'atualizar') {
            $id       = filter_var($_POST['id_usuario'] ?? null, FILTER_VALIDATE_INT);
            $nome     = trim($_POST['nome'] ?? '');
            $email    = strtolower(trim($_POST['email'] ?? ''));
            $telefone = trim($_POST['telefone'] ?? '') ?: null;
            $tipo     = $_POST['tipo'] ?? '';
            $senha    = $_POST['senha'] ?? ''; // opcional na edição

            if (!$id) {
                responder('erro', 'ID inválido.');
            }
            if ($erro = validarDados($nome, $email, $tipo, $telefone)) {
                responder('erro', $erro);
            }
            if (emailEmUso($conexao, $email, $id)) {
                responder('erro', 'Este e-mail já está em uso por outro usuário.');
            }

            $stmt = $conexao->prepare(
                'UPDATE usuario SET nome = ?, email = ?, tipo = ?, telefone = ? WHERE id_usuario = ?'
            );
            $stmt->bind_param('ssssi', $nome, $email, $tipo, $telefone, $id);
            $stmt->execute();
            $stmt->close();

            // Troca de senha so se o campo foi preenchido
            if ($senha !== '') {
                if (strlen($senha) < 6) {
                    responder('erro', 'A nova senha deve ter no mínimo 6 caracteres.');
                }
                $hash = password_hash($senha, PASSWORD_DEFAULT);
                $stmt = $conexao->prepare('UPDATE usuario SET senha = ? WHERE id_usuario = ?');
                $stmt->bind_param('si', $hash, $id);
                $stmt->execute();
                $stmt->close();
            }

            responder('ok', 'Dados atualizados com sucesso.');
        }

        if ($acao === 'desativar' || $acao === 'excluir') {
            $id = filter_var($_POST['id_usuario'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) {
                responder('erro', 'ID inválido.');
            }

            if ($acao === 'desativar') {
                $stmt = $conexao->prepare('UPDATE usuario SET ativo = 0 WHERE id_usuario = ? AND ativo = 1');
                $msgOk = 'Conta desativada com sucesso.';
            } else {
                $stmt = $conexao->prepare('DELETE FROM usuario WHERE id_usuario = ?');
                $msgOk = 'Conta excluída definitivamente.';
            }

            $stmt->bind_param('i', $id);
            $stmt->execute();
            $afetados = $stmt->affected_rows;
            $stmt->close();

            if ($afetados === 0) {
                responder('erro', 'Usuário não encontrado ou já desativado.');
            }
            responder('ok', $msgOk);
        }

        responder('erro', 'Ação POST inválida.');
    }

    responder('erro', 'Método não permitido.');

} catch (mysqli_sql_exception $e) {
    responder('erro', 'Erro ao executar a operação no banco de dados.');
}
