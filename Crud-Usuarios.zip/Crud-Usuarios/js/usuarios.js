
const API = '../php/usuarios.php';

const form        = document.getElementById('formUsuario');
const alerta      = document.getElementById('alerta');
const tabela      = document.getElementById('tabelaUsuarios');
const perfilBox   = document.getElementById('perfil');
const inputSenha  = document.getElementById('senha');

let listaAtual  = [];   // cache da listagem (usado para preencher o formulário na edição)
let perfilAtual = null; // id do perfil exibido no momento

document.addEventListener('DOMContentLoaded', () => {
    carregarUsuarios();
    form.addEventListener('submit', salvar);
    document.getElementById('btnCancelar').addEventListener('click', limparForm);
    tabela.addEventListener('click', onAcao);
});

async function api(url, opcoes) {
    try {
        const resp = await fetch(url, opcoes);
        return await resp.json();
    } catch (e) {
        return { status: 'erro', mensagem: 'Falha de comunicação com o servidor.', data: null };
    }
}

// Escapa texto para evitar injeção de HTML na tela
function esc(valor) {
    return String(valor ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function mostrarAlerta(status, mensagem) {
    alerta.className = 'alert ' + (status === 'ok' ? 'alert-success' : 'alert-danger');
    alerta.textContent = mensagem;
    setTimeout(() => alerta.classList.add('d-none'), 4000);
}

async function carregarUsuarios() {
    const json = await api(`${API}?acao=listar`);
    if (json.status !== 'ok') {
        return mostrarAlerta('erro', json.mensagem);
    }
    listaAtual = json.data;
    renderizarTabela(listaAtual);
}

function renderizarTabela(lista) {
    document.getElementById('total').textContent = `${lista.length} registro(s)`;

    if (lista.length === 0) {
        tabela.innerHTML = '<tr><td colspan="5" class="text-center text-muted py-4">Nenhum usuário cadastrado.</td></tr>';
        return;
    }

    tabela.innerHTML = lista.map(u => `
        <tr>
            <td>${esc(u.nome)}</td>
            <td>${esc(u.email)}</td>
            <td><span class="badge ${u.tipo === 'vendedor' ? 'bg-info text-dark' : 'bg-primary'}">${esc(u.tipo)}</span></td>
            <td>${Number(u.ativo) === 1
                ? '<span class="text-success">Ativa</span>'
                : '<span class="text-danger">Desativada</span>'}</td>
            <td class="text-end text-nowrap">
                <button class="btn btn-sm btn-outline-secondary" data-acao="perfil" data-id="${u.id_usuario}">Perfil</button>
                <button class="btn btn-sm btn-outline-primary" data-acao="editar" data-id="${u.id_usuario}">Editar</button>
                <button class="btn btn-sm btn-outline-warning" data-acao="desativar" data-id="${u.id_usuario}">Desativar</button>
                <button class="btn btn-sm btn-outline-danger" data-acao="excluir" data-id="${u.id_usuario}">Excluir</button>
            </td>
        </tr>`).join('');
}

function onAcao(e) {
    const btn = e.target.closest('button[data-acao]');
    if (!btn) return;

    const id = btn.dataset.id;
    switch (btn.dataset.acao) {
        case 'perfil':    carregarPerfil(id); break;
        case 'editar':    preencherFormulario(id); break;
        case 'desativar': desativarUsuario(id); break;
        case 'excluir':   excluirUsuario(id); break;
    }
}

async function carregarPerfil(id) {
    const json = await api(`${API}?acao=perfil&id=${encodeURIComponent(id)}`);
    if (json.status !== 'ok') {
        perfilAtual = null;
        perfilBox.innerHTML = '<p class="text-muted mb-0">Perfil indisponível.</p>';
        return mostrarAlerta('erro', json.mensagem);
    }

    perfilAtual = id;
    const p = json.data;
    perfilBox.innerHTML = `
        <dl class="row mb-0">
            <dt class="col-sm-4">Nome</dt>      <dd class="col-sm-8">${esc(p.nome)}</dd>
            <dt class="col-sm-4">E-mail</dt>    <dd class="col-sm-8">${esc(p.email)}</dd>
            <dt class="col-sm-4">Telefone</dt>  <dd class="col-sm-8">${esc(p.telefone || '—')}</dd>
            <dt class="col-sm-4">Tipo</dt>      <dd class="col-sm-8">${esc(p.tipo)}</dd>
            <dt class="col-sm-4">Situação</dt>  <dd class="col-sm-8">${Number(p.ativo) === 1 ? 'Ativa' : 'Desativada'}</dd>
            <dt class="col-sm-4">Cadastro</dt>  <dd class="col-sm-8">${esc(p.data_cadastro)}</dd>
        </dl>`;
}

async function salvar(e) {
    e.preventDefault();

    const editando = document.getElementById('id_usuario').value !== '';
    const dados = new FormData(form);
    dados.append('acao', editando ? 'atualizar' : 'criar');

    const json = await api(API, { method: 'POST', body: dados });
    mostrarAlerta(json.status, json.mensagem);

    if (json.status === 'ok') {
        limparForm();
        await atualizarTelas();
    }
}

function preencherFormulario(id) {
    const u = listaAtual.find(x => String(x.id_usuario) === String(id));
    if (!u) return;

    document.getElementById('id_usuario').value = u.id_usuario;
    document.getElementById('nome').value       = u.nome;
    document.getElementById('email').value      = u.email;
    document.getElementById('telefone').value   = u.telefone || '';
    document.getElementById('tipo').value       = u.tipo;

    inputSenha.value = '';
    inputSenha.required = false;
    document.getElementById('dicaSenha').textContent = '(deixe em branco para manter a senha atual)';
    document.getElementById('tituloForm').textContent = `Editar usuário #${u.id_usuario}`;
    document.getElementById('btnSalvar').textContent = 'Salvar alterações';
    document.getElementById('nome').focus();
}

function limparForm() {
    form.reset();
    document.getElementById('id_usuario').value = '';
    inputSenha.required = true;
    document.getElementById('dicaSenha').textContent = '(mínimo 6 caracteres)';
    document.getElementById('tituloForm').textContent = 'Novo usuário';
    document.getElementById('btnSalvar').textContent = 'Cadastrar';
}

async function desativarUsuario(id) {
    if (!confirm('Desativar esta conta? Ela continuará no banco, mas ficará inativa.')) return;
    await enviarAcao('desativar', id);
}

async function excluirUsuario(id) {
    if (!confirm('Excluir DEFINITIVAMENTE este usuário? Essa ação não pode ser desfeita.')) return;
    await enviarAcao('excluir', id);
}

async function enviarAcao(acao, id) {
    const dados = new FormData();
    dados.append('acao', acao);
    dados.append('id_usuario', id);

    const json = await api(API, { method: 'POST', body: dados });
    mostrarAlerta(json.status, json.mensagem);

    if (json.status === 'ok') {
        if (String(perfilAtual) === String(id)) {
            if (acao === 'excluir') {
                perfilAtual = null;
                perfilBox.innerHTML = '<p class="text-muted mb-0">Usuário excluído.</p>';
            }
        }
        await atualizarTelas();
    }
}

async function atualizarTelas() {
    await carregarUsuarios();
    if (perfilAtual) {
        await carregarPerfil(perfilAtual);
    }
}
