-- Script de criação do banco e da tabela (executar no phpMyAdmin, aba SQL)
CREATE DATABASE IF NOT EXISTS crud_usuarios
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE crud_usuarios;

DROP TABLE IF EXISTS usuario;

CREATE TABLE usuario (
    id_usuario    INT AUTO_INCREMENT PRIMARY KEY,
    nome          VARCHAR(100)  NOT NULL,
    email         VARCHAR(150)  NOT NULL UNIQUE,
    senha         VARCHAR(255)  NOT NULL,           -- armazenada como hash (password_hash)
    tipo          ENUM('cliente', 'vendedor') NOT NULL,
    telefone      VARCHAR(20)   NULL,
    ativo         TINYINT(1)    NOT NULL DEFAULT 1, -- 1 = ativa, 0 = desativada
    data_cadastro DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- Registros de exemplo
-- As senhas abaixo são placeholders de exemplo; cadastre novos usuários pela tela para testar o login de senha real.
INSERT INTO usuario (nome, email, senha, tipo, telefone, ativo) VALUES
('Matheus',   'matheusmaceno@email.com',   '$2y$10$exemploDeHashNaoUtilizadoParaLogin000000000000', 'cliente',  '(11) 98888-1111', 1),
('Carlos', 'carlos@loja.com', '$2y$10$exemploDeHashNaoUtilizadoParaLogin000000000000', 'vendedor', '(11) 97777-2222', 1),
('Beatriz','bia@email.com',   '$2y$10$exemploDeHashNaoUtilizadoParaLogin000000000000', 'cliente',  '(21) 96666-3333', 0);
