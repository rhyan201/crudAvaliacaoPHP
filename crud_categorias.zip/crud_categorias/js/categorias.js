// js/categorias.js
// Caminho dos PHP em relação a html/categorias.html
const URL_PHP = '../php/';

document.addEventListener('DOMContentLoaded', () => {
    buscar();
});

// Botão Enviar: sem id preenchido = novo; com id preenchido = alterar
document.getElementById('bt_enviar').addEventListener('click', () => {
    if (document.getElementById('id').value === '') {
        novo();
    } else {
        alterar();
    }
});

document.getElementById('bt_cancelar').addEventListener('click', () => {
    limparCampos();
});

// ---------- READ: listar todas ----------
async function buscar() {
    const retorno = await fetch(URL_PHP + 'categoria_get.php');
    const resposta = await retorno.json();

    if (resposta.status == 'ok') {
        preencherLista(resposta.data);
    } else {
        preencherLista([]); // "Nao ha registros": mostra a lista vazia
    }
}

function preencherLista(tabela) {
    const ul = document.getElementById('p_categorias');
    ul.innerHTML = '';

    for (const c of tabela) {
        const li = document.createElement('li');
        li.className = 'list-group-item d-flex justify-content-between align-items-center';

        const texto = document.createElement('span');
        texto.textContent = c.nome; // textContent evita injetar HTML

        const botoes = document.createElement('div');

        const btCarregar = document.createElement('button');
        btCarregar.className = 'btn btn-sm btn-primary me-2';
        btCarregar.textContent = 'Carregar';
        btCarregar.addEventListener('click', () => carregar(c.id));

        const btExcluir = document.createElement('button');
        btExcluir.className = 'btn btn-sm btn-danger';
        btExcluir.textContent = 'Excluir';
        btExcluir.addEventListener('click', () => excluir(c.id));

        botoes.append(btCarregar, btExcluir);
        li.append(texto, botoes);
        ul.appendChild(li);
    }
}

// ---------- CREATE ----------
async function novo() {
    const fd = new FormData();
    fd.append('nome', document.getElementById('nome').value);

    const retorno = await fetch(URL_PHP + 'categoria_novo.php', {
        method: 'POST',
        body: fd
    });
    const resposta = await retorno.json();

    if (resposta.status == 'ok') {
        alert('SUCESSO: ' + resposta.mensagem);
        limparCampos();
        buscar();
    } else {
        alert('ERRO: ' + resposta.mensagem);
    }
}

// ---------- UPDATE, fase 1: busca o registro pelo id e preenche o formulário ----------
async function carregar(id) {
    const retorno = await fetch(URL_PHP + 'categoria_get.php?id=' + id);
    const resposta = await retorno.json();

    if (resposta.status == 'ok') {
        const reg = resposta.data[0];
        document.getElementById('nome').value = reg.nome;
        document.getElementById('id').value = reg.id;
        document.getElementById('bt_enviar').textContent = 'Alterar';
        document.getElementById('bt_cancelar').classList.remove('d-none');
    } else {
        alert('ERRO: ' + resposta.mensagem);
    }
}

// ---------- UPDATE, fase 2: id na URL + dados no body ----------
async function alterar() {
    const id = document.getElementById('id').value;
    const fd = new FormData();
    fd.append('nome', document.getElementById('nome').value);

    const retorno = await fetch(URL_PHP + 'categoria_alterar.php?id=' + id, {
        method: 'POST',
        body: fd
    });
    const resposta = await retorno.json();

    if (resposta.status == 'ok') {
        alert('SUCESSO: ' + resposta.mensagem);
        limparCampos();
        buscar();
    } else {
        alert('ERRO: ' + resposta.mensagem);
    }
}

// ---------- DELETE ----------
async function excluir(id) {
    if (!confirm('Excluir esta categoria?')) return;

    const retorno = await fetch(URL_PHP + 'categoria_excluir.php?id=' + id);
    const resposta = await retorno.json();

    alert(resposta.mensagem);
    if (resposta.status == 'ok') {
        buscar();
    }
}

function limparCampos() {
    document.getElementById('cadcat').reset();
    document.getElementById('id').value = '';
    document.getElementById('bt_enviar').textContent = 'Enviar';
    document.getElementById('bt_cancelar').classList.add('d-none');
}
