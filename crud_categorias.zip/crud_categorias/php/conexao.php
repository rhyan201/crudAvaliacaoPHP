<?php // php/conexao.php
// Único arquivo de conexão com o banco. Os outros PHP fazem include_once dele.
$servidor   = 'localhost:3306'; // host:porta
$usuario    = 'root';           // usuário padrão do XAMPP
$senha      = '';               // senha vazia no XAMPP padrão
$nome_banco = 'crud_categorias';

$conexao = new mysqli($servidor, $usuario, $senha, $nome_banco);

if ($conexao->connect_error) {
    header('Content-type: application/json; charset=utf-8');
    echo json_encode([
        'status'   => 'nok',
        'mensagem' => 'Falha na conexão: ' . $conexao->connect_error,
        'data'     => []
    ]);
    exit;
}

$conexao->set_charset('utf8mb4');
