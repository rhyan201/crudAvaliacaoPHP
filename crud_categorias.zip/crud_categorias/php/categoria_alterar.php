<?php // php/categoria_alterar.php
include_once('conexao.php');

$retorno = ['status' => '', 'mensagem' => '', 'data' => []];

// ID vem na URL (?id=42) e o dado novo vem no body ($_POST)
if (isset($_GET['id'])) {
    $nome = trim($_POST['nome'] ?? '');

    if (empty($nome)) {
        $retorno['status']   = 'nok';
        $retorno['mensagem'] = 'Nome da categoria e obrigatorio.';
    } else {
        $stmt = $conexao->prepare('UPDATE categoria SET nome = ? WHERE id = ?');
        $stmt->bind_param('si', $nome, $_GET['id']); // s = nome, i = id

        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $retorno['status']   = 'ok';
            $retorno['mensagem'] = 'Registro alterado com sucesso.';
        } else {
            $retorno['status']   = 'nok';
            $retorno['mensagem'] = 'Nao foi possivel alterar o registro.';
        }
        $stmt->close();
    }
} else {
    $retorno['status']   = 'nok';
    $retorno['mensagem'] = 'ID nao informado.';
}

$conexao->close();

header('Content-type: application/json; charset=utf-8');
echo json_encode($retorno);
