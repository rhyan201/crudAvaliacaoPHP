<?php // php/categoria_novo.php
include_once('conexao.php');

$retorno = ['status' => '', 'mensagem' => '', 'data' => []];

// Dados do FormData chegam via $_POST
$nome = trim($_POST['nome'] ?? '');

// Validação antes de executar o INSERT
if (empty($nome)) {
    $retorno['status']   = 'nok';
    $retorno['mensagem'] = 'Nome da categoria e obrigatorio.';
    header('Content-type: application/json; charset=utf-8');
    echo json_encode($retorno);
    exit;
}

$stmt = $conexao->prepare('INSERT INTO categoria(nome) VALUES (?)');
$stmt->bind_param('s', $nome); // 's' = string
$stmt->execute();

if ($stmt->affected_rows > 0) {
    $retorno['status']   = 'ok';
    $retorno['mensagem'] = 'Registro inserido com sucesso';
} else {
    $retorno['status']   = 'nok';
    $retorno['mensagem'] = 'Falha ao inserir o registro';
}

$stmt->close();
$conexao->close();

header('Content-type: application/json; charset=utf-8');
echo json_encode($retorno);
