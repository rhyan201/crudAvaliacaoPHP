-- EcoWaste - CRUD de Categorias de Produtos
CREATE DATABASE IF NOT EXISTS crud_categorias CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE crud_categorias;

CREATE TABLE IF NOT EXISTS categoria (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL
);

INSERT INTO categoria (nome) VALUES
  ('Frutas'),
  ('Verduras e Legumes'),
  ('Padaria'),
  ('Laticínios');
