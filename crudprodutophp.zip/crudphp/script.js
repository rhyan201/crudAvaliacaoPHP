// Constante com o caminho da sua pasta onde estão os arquivos PHP
const API_URL = "./"; // Ajuste se os arquivos estiverem em uma subpasta, ex: "php/"

// Assim que a página abre, carrega os produtos do banco de dados MySQL
document.addEventListener("DOMContentLoaded", () => {
  listar();
});

// Evento do botão enviar (Cadastrar ou Salvar Alteração)
document.getElementById("bt_enviar").addEventListener("click", () => {
  let nome = document.getElementById("nome").value;
  let quantidade = document.getElementById("quantidade").value;
  let preconormal = document.getElementById("preconormal").value;
  let precopromo = document.getElementById("precopromo").value;
  let horario = document.getElementById("horario").value;

  if (!validar(nome, quantidade, preconormal, precopromo)) {
    return;
  }

  // Cria o FormData enviando os nomes corretos que o PHP espera
  let formData = new FormData();
  formData.append("nome", nome);
  formData.append("quantidade", quantidade);
  formData.append("precoNormal", preconormal); // Ajustado para precoNormal
  formData.append("precoPromo", precopromo);   // Ajustado para precoPromo
  formData.append("horario", horario);

  let idEmEdicao = document.getElementById("bt_enviar").getAttribute("data-id");

  if (idEmEdicao) {
    fetch(`${API_URL}alterar_produto.php?id=${idEmEdicao}`, {
      method: "POST",
      body: formData
    })
    .then(response => response.json())
    .then(resultado => {
      alert(resultado.mensagem);
      if (resultado.status === "ok") {
        limparCampos();
        document.getElementById("bt_enviar").removeAttribute("data-id");
        document.getElementById("bt_enviar").innerText = "Enviar";
        document.getElementById("alterar").innerHTML = "";
        listar();
      }
    })
    .catch(erro => console.error("Erro na alteração:", erro));
  } else {
    fetch(`${API_URL}cadastro_produto.php`, {
      method: "POST",
      body: formData
    })
    .then(response => response.json())
    .then(resultado => {
      alert(resultado.mensagem);
      if (resultado.status === "ok") {
        limparCampos();
        listar();
      }
    })
    .catch(erro => console.error("Erro no cadastro:", erro));
  }
});

function listar() {
  fetch(`${API_URL}visualizar_produto.php`)
    .then(response => response.json())
    .then(resultado => {
      let p_produtos = document.getElementById("p_produtos");
      p_produtos.innerHTML = ""; // Limpa a lista antes de renderizar

      if (resultado.status === "ok" && resultado.data) {
        let lista = resultado.data;

        for (let produto of lista) {
          // Ajustado para ler 'precoNormal' e 'precoPromo' vindos do seu PHP
          p_produtos.innerHTML += `<li>
            <details>
                <summary>${produto.nome}</summary>
                <p>Quantidade: ${produto.quantidade} kg</p>
                <p>Preço normal: R$ ${Number(produto.precoNormal).toFixed(2)}</p>
                <p>Preço promocional: R$ ${Number(produto.precoPromo).toFixed(2)}</p>
                <p>Horário: ${produto.horario ? new Date(produto.horario).toLocaleString("pt-BR") : "Não informado"}</p>
            </details>
            <div class="produto-acoes">
                <button onclick="excluir(${produto.id})">Excluir</button>
                <button onclick="carregarParaEditar(${produto.id}, '${produto.nome}', ${produto.quantidade}, ${produto.precoNormal}, ${produto.precoPromo}, '${produto.horario}')">Carregar</button>
            </div>
          </li>`;
        }
      } else {
        p_produtos.innerHTML = `<p style="grid-column: span 2; text-align: center;">${resultado.mensagem || "Nenhum produto cadastrado."}</p>`;
      }
    })
    .catch(erro => console.error("Erro ao listar:", erro));
}

// Função para Excluir o Produto no Banco (DELETE)
function excluir(id) {
  if (confirm("Deseja realmente excluir este produto?")) {
    fetch(`${API_URL}deletar_produto.php?id=${id}`)
      .then(response => response.json())
      .then(resultado => {
        alert(resultado.mensagem);
        if (resultado.status === "ok") {
          listar();
        }
      })
      .catch(erro => console.error("Erro ao excluir:", erro));
  }
}

// Preenche os campos do formulário para edição
// Preenche os campos do formulário para edição (Ajustado para precoNormal e precoPromo)
function carregarParaEditar(id, nome, quantidade, precoNormal, precoPromo, horario) {
  document.getElementById("nome").value = nome;
  document.getElementById("quantidade").value = quantidade;
  document.getElementById("preconormal").value = precoNormal;
  document.getElementById("precopromo").value = precoPromo;
  
  // Formata a data para o input datetime-local se ela existir
  if (horario) {
    document.getElementById("horario").value = horario.replace(" ", "T");
  }
  
  // Guarda o ID temporariamente no botão enviar para sabermos que é uma edição
  let btnEnviar = document.getElementById("bt_enviar");
  btnEnviar.setAttribute("data-id", id);
  btnEnviar.innerText = "Salvar Alteração";

  // Cria um botão de cancelar edição caso o usuário desista
  document.getElementById("alterar").innerHTML = `
    <button type="button" onclick="cancelarEdicao()" style="background: #a94442;">Cancelar Edição</button>
  `;
}

function cancelarEdicao() {
  limparCampos();
  document.getElementById("bt_enviar").removeAttribute("data-id");
  document.getElementById("bt_enviar").innerText = "Enviar";
  document.getElementById("alterar").innerHTML = "";
}

function limparCampos() {
  document.getElementById("cadprod").reset();
}

// Sua função de validação original mantida intacta
function validar(nome, quantidade, preconormal, precopromo) {
  if (
    nome.trim() === "" ||
    quantidade === "" ||
    preconormal === "" ||
    precopromo === ""
  ) {
    alert("Preencha todos os campos!");
    return false;
  }
  if (Number(precopromo) >= Number(preconormal)) {
    alert("O preço promocional precisa ser menor que o preço normal!");
    return false;
  }
  if (
    Number(quantidade) < 0 || // Agora aceita 0 (para poder excluir depois)
    Number(preconormal) <= 0 ||
    Number(precopromo) <= 0
  ) {
    alert("Os valores precisam ser válidos!"); 
    return false;
  }
  return true;
}