<?php
header('Content-Type: application/json; charset=utf-8');
include_once('conexao.php');

$retorno = ['status' => 'nok', 'mensagem' => '', 'data' => []];

$id = $_GET['id'] ?? null;

if (empty($id)) {
    $retorno['mensagem'] = 'E necessario informar um ID para exclusao.';
    echo json_encode($retorno);
    exit;
}

// 1. Consulta prévia para verificar a existência e o estoque do produto
$sqlCheck = "SELECT id, quantidade FROM produto WHERE id = ?";
$stmtCheck = $conexao->prepare($sqlCheck);
$stmtCheck->bind_param('i', $id);
$stmtCheck->execute();
$resCheck = $stmtCheck->get_result();

if ($resCheck->num_rows === 0) {
    $retorno['mensagem'] = 'Produto nao encontrado.';
    $stmtCheck->close();
    $conexao->close();
    echo json_encode($retorno);
    exit;
}

$produto = $resCheck->fetch_assoc();
$stmtCheck->close();

// 2. Regra de negócio: produto com quantidade > 0 não pode ser excluído
if (intval($produto['quantidade']) > 0) {
    $retorno['mensagem'] = 'Produto com quantidade nao pode ser excluido.';
    $conexao->close();
    echo json_encode($retorno);
    exit;
}

// 3. Executa a exclusão
$sqlDel = "DELETE FROM produto WHERE id = ?";
$stmtDel = $conexao->prepare($sqlDel);
$stmtDel->bind_param('i', $id);

if ($stmtDel->execute()) {
    $retorno['status'] = 'ok';
    $retorno['mensagem'] = 'Produto excluido.';
} else {
    $retorno['mensagem'] = 'Falha ao excluir o produto.';
}

$stmtDel->close();
$conexao->close();
echo json_encode($retorno);
?>
