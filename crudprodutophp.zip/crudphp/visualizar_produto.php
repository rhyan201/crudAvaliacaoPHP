<?php
header('Content-Type: application/json; charset=utf-8');
include_once('conexao.php');

$retorno = ['status' => 'nok', 'mensagem' => '', 'data' => []];

$sql = "SELECT id, nome, precoNormal, precoPromo, quantidade, horario FROM produto ORDER BY nome ASC";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$resultado = $stmt->get_result();

$produtos = [];
while ($linha = $resultado->fetch_assoc()) {
    $produtos[] = [
        'id' => intval($linha['id']),
        'nome' => $linha['nome'],
        'precoNormal' => floatval($linha['precoNormal']),
        'precoPromo' => floatval($linha['precoPromo']),
        'quantidade' => intval($linha['quantidade']),
        'horario' => $linha['horario']
    ];
}

if (count($produtos) > 0) {
    $retorno['status'] = 'ok';
    $retorno['mensagem'] = 'Produtos listados com sucesso.';
    $retorno['data'] = $produtos;
} else {
    $retorno['mensagem'] = 'Nao ha produtos disponiveis.';
}

$stmt->close();
$conexao->close();
echo json_encode($retorno);
?>
