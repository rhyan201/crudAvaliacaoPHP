<?php
// Informa ao cliente que a resposta sera JSON codificado em UTF-8.
header('Content-type: application/json; charset=utf-8');
// Carrega a conexao com o banco uma unica vez.
include_once('conexao.php');

// Estrutura padrao da resposta: comeca como "nok" e pode ser atualizada abaixo.
$retorno = [
    'status' => 'nok',
    'mensagem' => '',
    'data' => [],
];

// Le o ID pela URL (GET); se nao vier, usa null.
$id = $_GET['id'] ?? null;
// Le o nome enviado pelo formulario (POST); se nao vier, usa texto vazio.
$nome = $_POST['nome'] ?? '';
// Le o preco normal enviado pelo formulario; se nao vier, usa zero.
$precoNormal = $_POST['precoNormal'] ?? 0;
// Le o preco promocional enviado pelo formulario; se nao vier, usa zero.
$precoPromo = $_POST['precoPromo'] ?? 0;
// Le a quantidade do produto; se nao vier, assume 0.
$quantidade = $_POST['quantidade'] ?? 0;
// Le o horario do produto; se nao vier, assume o horario atual.
$horario = $_POST['horario'] ?? date('Y-m-d H:i:s');

// Impede a alteracao quando o ID nao foi informado.
if (empty($id)) {
    // Define a mensagem de erro na resposta.
    $retorno['mensagem'] = 'ID nao informado.';
    // Converte o array para JSON e o envia ao cliente.
    echo json_encode($retorno);
    // Encerra o script para nao continuar ate a atualizacao.
    exit;
}

// Impede a alteracao quando o preco e zero ou negativo.
if ($precoNormal <= 0) {
    $retorno['mensagem'] = 'Preco invalido.';
    echo json_encode($retorno);
    exit;
}

if ($precoPromo <= 0) {
    $retorno['mensagem'] = 'Preco invalido.';
    echo json_encode($retorno);
    exit;
}

// Consulta se existe um produto com o ID recebido.
$sqlCheck = "SELECT id FROM produto WHERE id = ?";
// Prepara a consulta para inserir o ID com seguranca, sem concatena-lo no SQL.
$stmtCheck = $conexao->prepare($sqlCheck);
// Associa o ID ao marcador ?; "i" indica que o valor e inteiro.
$stmtCheck->bind_param('i', $id);
// Executa a consulta preparada.
$stmtCheck->execute();
// Obtem o resultado para verificar se o produto existe.
$resCheck = $stmtCheck->get_result();

// Se nenhuma linha foi encontrada, nao ha produto para alterar.
if ($resCheck->num_rows === 0) {
    $retorno['mensagem'] = 'Produto nao encontrado.';
    // Fecha a consulta e a conexao antes de responder.
    $stmtCheck->close();
    $conexao->close();
    echo json_encode($retorno);
    // Interrompe o script para nao tentar atualizar um produto inexistente.
    exit;
}
// Fecha a consulta de verificacao, pois ela ja foi usada.
$stmtCheck->close();

// Atualiza nome, preco e quantidade do produto que corresponde ao ID.
$sql = "UPDATE produto SET nome = ?, quantidade = ?, precoNormal = ?, precoPromo = ?, horario = ? WHERE id = ?";
// Prepara a atualizacao usando marcadores para os valores.
$stmt = $conexao->prepare($sql);
// Associa os valores aos marcadores: texto, decimal, decimal, inteiro e datetime.
$stmt->bind_param('siiddi', $nome, $quantidade, $precoNormal, $precoPromo, $horario, $id);

// Executa a atualizacao e verifica se o banco aceitou a consulta.
if ($stmt->execute()) {
    // Informa que a operacao foi executada sem erro.
    $retorno['status'] = 'ok';
    $retorno['mensagem'] = 'Produto alterado com sucesso.';
} else {
    // Informa que houve falha ao executar a atualizacao.
    $retorno['mensagem'] = 'Falha ao alterar o produto.';
}

// Libera a instrucao preparada e encerra a conexao com o banco.
$stmt->close();
$conexao->close();
// Envia a resposta final como JSON.
echo json_encode($retorno);
?>
