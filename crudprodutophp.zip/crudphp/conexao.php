<?php
// Ativar exibição de erros temporariamente para depuração
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Define o endereco do servidor MySQL.
$host = 'localhost';
// Define o usuario usado para conectar ao banco de dados.
$usuario = 'root';
// Define a senha do usuario do banco; neste caso, esta vazia.
$senha = '';
// Define o nome do banco de dados que sera utilizado.
$banco = 'crudproduto';

// Cria a conexao com o MySQL usando as configuracoes acima.
$conexao = new mysqli($host, $usuario, $senha, $banco);
// Verifica se a conexao falhou.
if ($conexao->connect_error) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
        'status' => 'nok',
        'mensagem' => 'Erro de conexão: ' . $conexao->connect_error,
        'data' => []
    ]);
    exit;
}
// Define UTF-8 completo para que caracteres acentuados sejam tratados corretamente.
$conexao->set_charset("utf8mb4");
?>
