<?php
header('Content-type: application/json; charset=utf-8'); // informa o navegador que a resposta sera json
include_once('conexao.php'); // arquivo de conexao com o banco de dados, 'once' evita que ele seja incluido mais de uma vez

$retorno = [ // array que organiza a resposta que o script enviara
    'status' => 'nok',
    'mensagem' => '',
    'data' => []
];

$nome = $_POST['nome'] ?? '';
$precoNormal = $_POST['precoNormal'] ?? '';
$precoPromo = $_POST['precoPromo'] ??'';
$quantidade = isset($_POST['quantidade']) && $_POST['quantidade'] !== '' ? intval($_POST['quantidade']) : 0; // transformando em inteiro para o banco de dados
$horario = isset($_POST['horario']) ? $_POST['horario'] : date('Y-m-d H:i:s'); // transformando em inteiro para o banco de dados, padrao 1 (ativo)

// Validando campos obrigatorios
if (empty($nome) || empty($precoNormal) || empty($precoPromo)) {
    $retorno = [
        'status' => 'nok',
        'mensagem' => 'Nome e precos sao obrigatorios!',
        'data' => []
    ];
    echo json_encode($retorno);
    exit;
}

$sql = "INSERT INTO produto (nome, precoNormal, precoPromo, quantidade, horario) VALUES (?, ?, ?, ?, ?)"; // comando sql para inserir um produto na tabela
$stmt = $conexao->prepare($sql); // prepara o comando fazendo a conexao com o banco de dados 

if ($stmt) {
    $stmt->bind_param('ssddd', $nome, $precoNormal, $precoPromo, $quantidade, $horario); // associa os valores aos '?' e o 'sdii' indica os tipos dos campos na ordem

    if ($stmt->execute() && $stmt->affected_rows > 0) { // executa o insert e verifica se alguma linha foi afetada
        $retorno['status'] = 'ok';
        $retorno['mensagem'] = 'Produto cadastrado com sucesso.';
    } else {
        $retorno['mensagem'] = 'Falha ao cadastrar o produto.';
    }
    $stmt->close(); // encerra a instrucao
} else {
    $retorno['mensagem'] = 'Erro na preparacao da consulta.';
}

$conexao->close(); // fecha a conexao com o banco
echo json_encode($retorno); // converte o retorno para json e envia a resposta
?>
