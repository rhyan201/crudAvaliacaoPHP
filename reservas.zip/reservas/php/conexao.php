<?php

$host    = 'localhost';
$usuario = 'root';
$senha   = '';
$banco   = 'crud_reservas';

function responder($status, $mensagem, $data = null){
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status'   => $status,
        'mensagem' => $mensagem,
        'data'     => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conexao = new mysqli($host, $usuario, $senha, $banco);
    $conexao->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status'   => 'erro',
        'mensagem' => 'Não foi possível conectar ao banco de dados.',
        'data'     => null
    ]);
    exit;
}
