<?php
    require_once __DIR__ . '/conexao.php';

    $acao = $_GET['acao'] ?? '';

    function protege(){
        session_start();
        if(!isset($_SESSION['usuario'])){
            responder('nok', 'Sessão expirada. Faça login novamente.');
        }
    }

    function reserva_get($conexao){
        protege();

        $campos = "id_reserva AS id, codigo, cliente, item, status,
                   DATE_FORMAT(data_criacao, '%d/%m/%Y %H:%i:%s') AS data_criacao";

        if(isset($_GET['id'])){
            $stmt = $conexao->prepare("SELECT $campos FROM reserva WHERE id_reserva = ?");
            $id = (int) $_GET['id'];
            $stmt->bind_param("i", $id);
        }else{
            $stmt = $conexao->prepare("SELECT $campos FROM reserva ORDER BY id_reserva DESC");
        }

        $stmt->execute();
        $tabela = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        $conexao->close();

        if(count($tabela) > 0){
            responder('ok', 'Sucesso, consulta efetuada.', $tabela);
        }
        responder('nok', 'Não há registros');
    }

    function reserva_novo($conexao){
        protege();

        $cliente = $_POST['cliente'];
        $item    = $_POST['item'];

        $caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $codigo = 'RES-';
        for($i = 0; $i < 6; $i++){
            $codigo .= $caracteres[random_int(0, strlen($caracteres) - 1)];
        }

        $stmt = $conexao->prepare("INSERT INTO reserva(codigo, cliente, item) VALUES(?,?,?)");
        $stmt->bind_param("sss", $codigo, $cliente, $item);
        $stmt->execute();
        $stmt->close();
        $conexao->close();

        responder('ok', 'Reserva criada com sucesso. Código: ' . $codigo);
    }

    function reserva_alterar($conexao){
        protege();

        $id      = (int) $_GET['id'];
        $cliente = $_POST['cliente'];
        $item    = $_POST['item'];

        $stmt = $conexao->prepare("UPDATE reserva SET cliente = ?, item = ? WHERE id_reserva = ?");
        $stmt->bind_param("ssi", $cliente, $item, $id);
        $stmt->execute();
        $stmt->close();
        $conexao->close();

        responder('ok', 'Registro alterado com sucesso.');
    }

    function reserva_cancelar($conexao){
        protege();

        $id = (int) $_GET['id'];

        $stmt = $conexao->prepare("UPDATE reserva SET status = 'cancelado' WHERE id_reserva = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $conexao->close();

        responder('ok', 'Reserva cancelada com sucesso.');
    }

    function reserva_excluir($conexao){
        protege();

        $id = (int) $_GET['id'];

        $stmt = $conexao->prepare("DELETE FROM reserva WHERE id_reserva = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $conexao->close();

        responder('ok', 'Registro excluído');
    }

    function reserva_validar($conexao){
        protege();

        $id             = (int) $_GET['id'];
        $codigoDigitado = strtoupper(trim($_POST['codigo']));

        $stmt = $conexao->prepare("SELECT codigo FROM reserva WHERE id_reserva = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $reserva = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if(!$reserva){
            responder('nok', 'Reserva não encontrada.');
        }
        if($reserva['codigo'] !== $codigoDigitado){
            responder('nok', 'Código de resgate inválido.');
        }

        $stmt = $conexao->prepare("UPDATE reserva SET status = 'concluido' WHERE id_reserva = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $conexao->close();

        responder('ok', 'Código validado! Pedido concluído.');
    }

    function usuario_login($conexao){
        $usuario = $_POST['usuario'];
        $senha   = $_POST['senha'];

        $stmt = $conexao->prepare("SELECT id_usuario AS id, nome, senha FROM usuario WHERE email = ? AND ativo = 1");
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $linha = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $conexao->close();

        if($linha && password_verify($senha, $linha['senha'])){
            session_start();
            $_SESSION['usuario'] = ['id' => $linha['id'], 'nome' => $linha['nome']];
            responder('ok', 'Login efetuado.');
        }

        responder('nok', 'Credenciais inválidas.');
    }

    function usuario_logoff(){
        session_start();
        session_unset();
        session_destroy();
        responder('ok', '');
    }

    function valida_sessao(){
        session_start();
        if(isset($_SESSION['usuario'])){
            responder('ok', '');
        }
        responder('nok', '');
    }

    switch($acao){
        case 'get':
            reserva_get($conexao);
            break;
        case 'novo':
            reserva_novo($conexao);
            break;
        case 'alterar':
            reserva_alterar($conexao);
            break;
        case 'cancelar':
            reserva_cancelar($conexao);
            break;
        case 'excluir':
            reserva_excluir($conexao);
            break;
        case 'validar':
            reserva_validar($conexao);
            break;
        case 'login':
            usuario_login($conexao);
            break;
        case 'logoff':
            usuario_logoff();
            break;
        case 'valida_sessao':
            valida_sessao();
            break;
        default:
            responder('nok', 'Ação inválida.');
    }
