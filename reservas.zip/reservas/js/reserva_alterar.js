document.addEventListener("DOMContentLoaded", () => {
    valida_sessao();
    const url = new URLSearchParams(window.location.search);
    const id = url.get("id");
    buscar(id);
});

async function buscar(id){
    const retorno = await fetch("../php/reserva.php?acao=get&id=" + id);
    const resposta = await retorno.json();
    if(resposta.status == "ok"){
        var registro = resposta.data[0];
        if(registro.status !== "pendente"){
            alert("Somente reservas pendentes podem ser alteradas.");
            window.location.href = "../home/";
            return;
        }
        document.getElementById("cliente").value = registro.cliente;
        document.getElementById("item").value = registro.item;
        document.getElementById("id").value = id;
    }else{
        alert("ERRO: " + resposta.mensagem);
        window.location.href = "../home/";
    }
}

document.getElementById("enviar").addEventListener("click", () => {
    alterar();
});

async function alterar(){
    var cliente = document.getElementById("cliente").value;
    var item    = document.getElementById("item").value;
    var id      = document.getElementById("id").value;

    const fd = new FormData();
    fd.append("cliente", cliente);
    fd.append("item", item);

    const retorno = await fetch("../php/reserva.php?acao=alterar&id=" + id, {
        method: 'POST',
        body: fd
    });
    const resposta = await retorno.json();
    if(resposta.status == "ok"){
        alert("SUCESSO: " + resposta.mensagem);
        window.location.href = '../home/';
    }else{
        alert("ERRO: " + resposta.mensagem);
    }
}
