async function valida_sessao(){
    const retorno = await fetch("../php/reserva.php?acao=valida_sessao");
    const resposta = await retorno.json();
    if(resposta.status == "nok"){
        window.location.href = '../login/';
    }
}
