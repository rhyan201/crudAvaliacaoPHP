document.getElementById("formLogin").addEventListener("submit", (e) => {
    e.preventDefault();
    login();
});

async function login(){
    var usuario = document.getElementById("usuario").value;
    var senha = document.getElementById("senha").value;
    const fd = new FormData();
    fd.append("usuario", usuario);
    fd.append("senha", senha);
    const retorno = await fetch("../php/reserva.php?acao=login", {
        method: "POST",
        body: fd
    });
    const resposta = await retorno.json();
    if(resposta.status == "ok"){
        window.location.href = "../home/";
    }else{
        alert(resposta.mensagem || "Credenciais inválidas.");
    }
}
