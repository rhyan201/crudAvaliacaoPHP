const STATUS = {
    pendente:  { texto: 'Pendente',  classe: 'pendente'  },
    concluido: { texto: 'Concluído', classe: 'concluido' },
    cancelado: { texto: 'Cancelado', classe: 'cancelado' }
};

document.addEventListener("DOMContentLoaded", () => {
    valida_sessao();
    buscar();
});

document.getElementById("novo").addEventListener("click", () => {
    window.location.href = 'reserva_novo.html';
});

document.getElementById("logoff").addEventListener("click", () => {
    logoff();
});

document.getElementById("lista").addEventListener("click", (e) => {
    const botao = e.target.closest("button[data-acao]");
    if(!botao) return;
    const id = botao.dataset.id;
    switch(botao.dataset.acao){
        case 'alterar':  window.location.href = 'reserva_alterar.html?id=' + id; break;
        case 'validar':  validar(id); break;
        case 'cancelar': cancelar(id); break;
        case 'excluir':  excluir(id); break;
    }
});

async function logoff(){
    const retorno = await fetch("../php/reserva.php?acao=logoff");
    const resposta = await retorno.json();
    if(resposta.status == "ok"){
        window.location.href = '../login/';
    }
}

async function buscar(){
    const retorno = await fetch("../php/reserva.php?acao=get");
    const resposta = await retorno.json();
    if(resposta.status == "ok"){
        preencherTabela(resposta.data);
    }else{
        document.getElementById("lista").innerHTML =
            '<p class="vazio">Nenhuma reserva cadastrada.</p>';
    }
}

async function validar(id){
    const codigo = prompt("Digite o código de resgate para validar:", "");
    if(codigo === null) return;
    const fd = new FormData();
    fd.append("codigo", codigo.trim().toUpperCase());
    await executar("../php/reserva.php?acao=validar&id=" + id, fd);
}

async function cancelar(id){
    if(!confirm("Deseja realmente cancelar esta reserva?")) return;
    await executar("../php/reserva.php?acao=cancelar&id=" + id);
}

async function excluir(id){
    if(!confirm("Excluir DEFINITIVAMENTE esta reserva? Essa ação não pode ser desfeita.")) return;
    await executar("../php/reserva.php?acao=excluir&id=" + id);
}

async function executar(url, fd){
    const retorno = await fetch(url, fd ? { method: 'POST', body: fd } : {});
    const resposta = await retorno.json();
    alert(resposta.mensagem);
    if(resposta.status == "ok"){
        buscar();
    }
}

function preencherTabela(tabela){
    var html = `
        <table>
            <tr>
                <th>Código</th>
                <th>Cliente</th>
                <th>Oferta</th>
                <th>Data</th>
                <th>Status</th>
                <th>#</th>
            </tr>`;
    for(var i=0;i<tabela.length;i++){
        const r = tabela[i];
        const st = STATUS[r.status] || { texto: r.status, classe: '' };
        const pendente = r.status === 'pendente';
        html += `
            <tr>
                <td><span class="codigo">${esc(r.codigo)}</span></td>
                <td>${esc(r.cliente)}</td>
                <td>${esc(r.item)}</td>
                <td>${esc(r.data_criacao)}</td>
                <td><span class="status ${st.classe}">${esc(st.texto)}</span></td>
                <td class="acoes">
                    ${pendente ? `
                    <button data-acao="alterar" data-id="${r.id}">Alterar</button>
                    <button data-acao="validar" data-id="${r.id}">Validar</button>
                    <button data-acao="cancelar" data-id="${r.id}">Cancelar</button>` : ''}
                    <button class="perigo" data-acao="excluir" data-id="${r.id}">Excluir</button>
                </td>
            </tr>`;
    }
    html += '</table>';
    document.getElementById("lista").innerHTML = html;
}
