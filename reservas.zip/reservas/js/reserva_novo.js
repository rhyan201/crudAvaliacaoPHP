document.addEventListener("DOMContentLoaded", () => {
    valida_sessao();
});

document.getElementById("enviar").addEventListener("click", () => {
    novo();
});

async function novo(){
    var cliente = document.getElementById("cliente").value;
    var item    = document.getElementById("item").value;

    const fd = new FormData();
    fd.append("cliente", cliente);
    fd.append("item", item);

    const retorno = await fetch("../php/reserva.php?acao=novo", {
        method: 'POST',
        body: fd
    });
    const resposta = await retorno.json();
    if(resposta.status == "ok"){
        alert("SUCESSO: " + resposta.mensagem);
        window.location.href = "../home/";
    }else{
        alert("ERRO: " + resposta.mensagem);
    }
}
