<?php

$host    = 'localhost';
$usuario = 'root';
$senha   = '';
$banco   = 'crud_reservas';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conexao = new mysqli($host, $usuario, $senha, $banco);
    $conexao->set_charset('utf8mb4');
    $conexao->query("SET time_zone = '-03:00'"); // horário de Brasília
} catch (mysqli_sql_exception $e) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status'   => 'erro',
        'mensagem' => 'Não foi possível conectar ao banco de dados.',
        'data'     => null
    ]);
    exit;
}
