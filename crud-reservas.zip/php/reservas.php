<?php

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexao.php';

const OFERTAS = ['Maçã', 'Banana', 'Laranja', 'Cenoura', 'Tomate'];

function responder($status, $mensagem, $data = null)
{
    echo json_encode([
        'status'   => $status,
        'mensagem' => $mensagem,
        'data'     => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function validarDados($cliente, $item)
{
    if ($cliente === '' || $item === '') {
        return 'Preencha todos os campos.';
    }
    if (mb_strlen($cliente) > 100) {
        return 'O nome do cliente deve ter no máximo 100 caracteres.';
    }
    if (!in_array($item, OFERTAS, true)) {
        return 'Oferta inválida.';
    }
    return null;
}

function gerarCodigo($conexao)
{
    $caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

    do {
        $codigo = 'RES-';
        for ($i = 0; $i < 6; $i++) {
            $codigo .= $caracteres[random_int(0, strlen($caracteres) - 1)];
        }

        $stmt = $conexao->prepare('SELECT id_reserva FROM reserva WHERE codigo = ?');
        $stmt->bind_param('s', $codigo);
        $stmt->execute();
        $stmt->store_result();
        $existe = $stmt->num_rows > 0;
        $stmt->close();
    } while ($existe);

    return $codigo;
}

function buscarReserva($conexao, $id)
{
    $stmt = $conexao->prepare(
        'SELECT id_reserva, codigo, cliente, item, status
         FROM reserva WHERE id_reserva = ?'
    );
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $reserva = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $reserva ?: null;
}

function exigirPendente($reserva, $mensagem)
{
    if (!$reserva) {
        responder('erro', 'Reserva não encontrada.');
    }
    if ($reserva['status'] !== 'pendente') {
        responder('erro', $mensagem);
    }
}

try {
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        $acao = $_GET['acao'] ?? 'listar';

        if ($acao === 'listar') {
            $stmt = $conexao->prepare(
                "SELECT id_reserva, codigo, cliente, item, status,
                        DATE_FORMAT(data_criacao, '%d/%m/%Y %H:%i:%s') AS data_criacao
                 FROM reserva ORDER BY id_reserva DESC"
            );
            $stmt->execute();
            $lista = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            responder('ok', 'Consulta efetuada.', $lista);
        }

        if ($acao === 'detalhe') {
            $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) {
                responder('erro', 'ID inválido.');
            }

            $stmt = $conexao->prepare(
                "SELECT id_reserva, codigo, cliente, item, status,
                        DATE_FORMAT(data_criacao, '%d/%m/%Y %H:%i:%s') AS data_criacao
                 FROM reserva WHERE id_reserva = ?"
            );
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $detalhe = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$detalhe) {
                responder('erro', 'Reserva não encontrada.');
            }
            responder('ok', 'Detalhes carregados.', $detalhe);
        }

        responder('erro', 'Ação GET inválida.');
    }

    if ($metodo === 'POST') {
        $acao = $_POST['acao'] ?? '';

        if ($acao === 'criar') {
            $cliente = trim($_POST['cliente'] ?? '');
            $item    = $_POST['item'] ?? '';

            if ($erro = validarDados($cliente, $item)) {
                responder('erro', $erro);
            }

            $codigo = gerarCodigo($conexao);

            $stmt = $conexao->prepare(
                'INSERT INTO reserva (codigo, cliente, item) VALUES (?, ?, ?)'
            );
            $stmt->bind_param('sss', $codigo, $cliente, $item);
            $stmt->execute();
            $novoId = $conexao->insert_id;
            $stmt->close();

            responder('ok', 'Reserva criada com sucesso. Código: ' . $codigo, [
                'id_reserva' => $novoId,
                'codigo'     => $codigo
            ]);
        }

        if ($acao === 'atualizar') {
            $id      = filter_var($_POST['id_reserva'] ?? null, FILTER_VALIDATE_INT);
            $cliente = trim($_POST['cliente'] ?? '');
            $item    = $_POST['item'] ?? '';

            if (!$id) {
                responder('erro', 'ID inválido.');
            }
            if ($erro = validarDados($cliente, $item)) {
                responder('erro', $erro);
            }
            exigirPendente(buscarReserva($conexao, $id), 'Somente reservas pendentes podem ser alteradas.');

            $stmt = $conexao->prepare('UPDATE reserva SET cliente = ?, item = ? WHERE id_reserva = ?');
            $stmt->bind_param('ssi', $cliente, $item, $id);
            $stmt->execute();
            $stmt->close();

            responder('ok', 'Reserva alterada com sucesso.');
        }

        if ($acao === 'validar') {
            $id             = filter_var($_POST['id_reserva'] ?? null, FILTER_VALIDATE_INT);
            $codigoDigitado = strtoupper(trim($_POST['codigo'] ?? ''));

            if (!$id) {
                responder('erro', 'ID inválido.');
            }

            $reserva = buscarReserva($conexao, $id);
            exigirPendente($reserva, 'Somente reservas pendentes podem ser validadas.');

            if (!hash_equals($reserva['codigo'], $codigoDigitado)) {
                responder('erro', 'Código de resgate inválido.');
            }

            $stmt = $conexao->prepare("UPDATE reserva SET status = 'concluido' WHERE id_reserva = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();

            responder('ok', 'Código validado! Pedido concluído.');
        }

        if ($acao === 'cancelar' || $acao === 'excluir') {
            $id = filter_var($_POST['id_reserva'] ?? null, FILTER_VALIDATE_INT);
            if (!$id) {
                responder('erro', 'ID inválido.');
            }

            if ($acao === 'cancelar') {
                exigirPendente(buscarReserva($conexao, $id), 'Somente reservas pendentes podem ser canceladas.');
                $stmt = $conexao->prepare("UPDATE reserva SET status = 'cancelado' WHERE id_reserva = ?");
                $msgOk = 'Reserva cancelada com sucesso.';
            } else {
                $stmt = $conexao->prepare('DELETE FROM reserva WHERE id_reserva = ?');
                $msgOk = 'Reserva excluída definitivamente.';
            }

            $stmt->bind_param('i', $id);
            $stmt->execute();
            $afetados = $stmt->affected_rows;
            $stmt->close();

            if ($afetados === 0) {
                responder('erro', 'Reserva não encontrada.');
            }
            responder('ok', $msgOk);
        }

        responder('erro', 'Ação POST inválida.');
    }

    responder('erro', 'Método não permitido.');

} catch (mysqli_sql_exception $e) {
    responder('erro', 'Erro ao executar a operação no banco de dados.');
}
