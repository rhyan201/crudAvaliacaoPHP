
const API = '../php/reservas.php';

const form      = document.getElementById('formReserva');
const alerta    = document.getElementById('alerta');
const tabela    = document.getElementById('tabelaReservas');
const detalhe   = document.getElementById('detalhe');

const STATUS = {
    pendente:  { texto: 'Pendente',  classe: 'bg-warning text-dark' },
    concluido: { texto: 'Concluído', classe: 'bg-success' },
    cancelado: { texto: 'Cancelado', classe: 'bg-danger' }
};

let listaAtual    = [];   // cache da listagem (usado para preencher o formulário na edição)
let detalheAtual  = null; // id da reserva exibida nos detalhes no momento
let timerAlerta   = null;

document.addEventListener('DOMContentLoaded', () => {
    carregarReservas();
    form.addEventListener('submit', salvar);
    document.getElementById('btnCancelar').addEventListener('click', limparForm);
    tabela.addEventListener('click', onAcao);
});

async function api(url, opcoes) {
    try {
        const resp = await fetch(url, opcoes);
        return await resp.json();
    } catch (e) {
        return { status: 'erro', mensagem: 'Falha de comunicação com o servidor.', data: null };
    }
}

function esc(valor) {
    return String(valor ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function seloStatus(status) {
    const s = STATUS[status] || { texto: status, classe: 'bg-secondary' };
    return `<span class="badge ${s.classe}">${esc(s.texto)}</span>`;
}

function mostrarAlerta(status, mensagem) {
    clearTimeout(timerAlerta);
    alerta.className = 'alert ' + (status === 'ok' ? 'alert-success' : 'alert-danger');
    alerta.textContent = mensagem;
    timerAlerta = setTimeout(() => alerta.classList.add('d-none'), 4000);
}

async function carregarReservas() {
    const json = await api(`${API}?acao=listar`);
    if (json.status !== 'ok') {
        return mostrarAlerta('erro', json.mensagem);
    }
    listaAtual = json.data;
    renderizarTabela(listaAtual);
}

function renderizarTabela(lista) {
    document.getElementById('total').textContent = `${lista.length} registro(s)`;

    if (lista.length === 0) {
        tabela.innerHTML = '<tr><td colspan="5" class="text-center text-muted py-4">Nenhuma reserva cadastrada.</td></tr>';
        return;
    }

    tabela.innerHTML = lista.map(r => {
        const pendente = r.status === 'pendente';
        return `
        <tr>
            <td><code>${esc(r.codigo)}</code></td>
            <td>${esc(r.cliente)}</td>
            <td>${esc(r.item)}</td>
            <td>${seloStatus(r.status)}</td>
            <td class="text-end text-nowrap">
                <button class="btn btn-sm btn-outline-secondary" data-acao="detalhe" data-id="${r.id_reserva}">Detalhes</button>
                ${pendente ? `
                <button class="btn btn-sm btn-outline-primary" data-acao="editar" data-id="${r.id_reserva}">Editar</button>
                <button class="btn btn-sm btn-outline-success" data-acao="validar" data-id="${r.id_reserva}">Validar</button>
                <button class="btn btn-sm btn-outline-warning" data-acao="cancelar" data-id="${r.id_reserva}">Cancelar</button>` : ''}
                <button class="btn btn-sm btn-outline-danger" data-acao="excluir" data-id="${r.id_reserva}">Excluir</button>
            </td>
        </tr>`;
    }).join('');
}

function onAcao(e) {
    const btn = e.target.closest('button[data-acao]');
    if (!btn) return;

    const id = btn.dataset.id;
    switch (btn.dataset.acao) {
        case 'detalhe':  carregarDetalhe(id); break;
        case 'editar':   preencherFormulario(id); break;
        case 'validar':  validarReserva(id); break;
        case 'cancelar': cancelarReserva(id); break;
        case 'excluir':  excluirReserva(id); break;
    }
}

async function carregarDetalhe(id) {
    const json = await api(`${API}?acao=detalhe&id=${encodeURIComponent(id)}`);
    if (json.status !== 'ok') {
        detalheAtual = null;
        detalhe.innerHTML = '<p class="text-muted mb-0">Detalhes indisponíveis.</p>';
        return mostrarAlerta('erro', json.mensagem);
    }

    detalheAtual = id;
    const r = json.data;
    detalhe.innerHTML = `
        <dl class="row mb-0">
            <dt class="col-sm-4">Código</dt>    <dd class="col-sm-8"><code>${esc(r.codigo)}</code></dd>
            <dt class="col-sm-4">Cliente</dt>   <dd class="col-sm-8">${esc(r.cliente)}</dd>
            <dt class="col-sm-4">Oferta</dt>    <dd class="col-sm-8">${esc(r.item)}</dd>
            <dt class="col-sm-4">Status</dt>    <dd class="col-sm-8">${seloStatus(r.status)}</dd>
            <dt class="col-sm-4">Criada em</dt> <dd class="col-sm-8">${esc(r.data_criacao)}</dd>
        </dl>`;
}

async function salvar(e) {
    e.preventDefault();

    const editando = document.getElementById('id_reserva').value !== '';
    const dados = new FormData(form);
    dados.append('acao', editando ? 'atualizar' : 'criar');

    const json = await api(API, { method: 'POST', body: dados });
    mostrarAlerta(json.status, json.mensagem);

    if (json.status === 'ok') {
        limparForm();
        await atualizarTelas();
    }
}

function preencherFormulario(id) {
    const r = listaAtual.find(x => String(x.id_reserva) === String(id));
    if (!r) return;

    document.getElementById('id_reserva').value = r.id_reserva;
    document.getElementById('cliente').value    = r.cliente;
    document.getElementById('item').value       = r.item;

    document.getElementById('tituloForm').textContent = `Editar reserva #${r.id_reserva}`;
    document.getElementById('btnSalvar').textContent = 'Salvar alterações';
    document.getElementById('cliente').focus();
}

function limparForm() {
    form.reset();
    document.getElementById('id_reserva').value = '';
    document.getElementById('tituloForm').textContent = 'Nova reserva';
    document.getElementById('btnSalvar').textContent = 'Criar reserva';
}

async function validarReserva(id) {
    const codigo = prompt('Digite o código de resgate para validar:', '');
    if (codigo === null) return;
    await enviarAcao('validar', id, { codigo: codigo.trim().toUpperCase() });
}

async function cancelarReserva(id) {
    if (!confirm('Deseja realmente cancelar esta reserva?')) return;
    await enviarAcao('cancelar', id);
}

async function excluirReserva(id) {
    if (!confirm('Excluir DEFINITIVAMENTE esta reserva? Essa ação não pode ser desfeita.')) return;
    await enviarAcao('excluir', id);
}

async function enviarAcao(acao, id, extras = {}) {
    const dados = new FormData();
    dados.append('acao', acao);
    dados.append('id_reserva', id);
    Object.entries(extras).forEach(([chave, valor]) => dados.append(chave, valor));

    const json = await api(API, { method: 'POST', body: dados });
    mostrarAlerta(json.status, json.mensagem);

    if (json.status === 'ok') {
        if (document.getElementById('id_reserva').value === String(id)) {
            limparForm();
        }
        if (acao === 'excluir' && String(detalheAtual) === String(id)) {
            detalheAtual = null;
            detalhe.innerHTML = '<p class="text-muted mb-0">Reserva excluída.</p>';
        }
        await atualizarTelas();
    }
}

async function atualizarTelas() {
    await carregarReservas();
    if (detalheAtual) {
        await carregarDetalhe(detalheAtual);
    }
}
