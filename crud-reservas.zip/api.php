<?php
declare(strict_types=1);

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

function responder(array $dados, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

function erro(string $mensagem, int $status = 400): void
{
    responder(['ok' => false, 'erro' => $mensagem], $status);
}

function gerarCodigo(PDO $pdo): string
{
    $caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $busca = $pdo->prepare('SELECT 1 FROM reservas WHERE codigo = :codigo');

    do {
        $codigo = 'RES-';

        for ($i = 0; $i < 6; $i++) {
            $codigo .= $caracteres[random_int(0, strlen($caracteres) - 1)];
        }

        $busca->execute([':codigo' => $codigo]);
        $existe = $busca->fetchColumn() !== false;
    } while ($existe);

    return $codigo;
}

function buscarReserva(PDO $pdo, $id): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM reservas WHERE id = :id');
    $stmt->execute([':id' => (int) $id]);
    $reserva = $stmt->fetch();

    return $reserva === false ? null : $reserva;
}

function formatarReserva(array $r): array
{
    return [
        'id'      => (int) $r['id'],
        'codigo'  => $r['codigo'],
        'cliente' => $r['cliente'],
        'item'    => $r['item'],
        'data'    => date('d/m/Y H:i:s', strtotime($r['criado_em'])),
        'status'  => $r['status'],
    ];
}

function validarCampos(array $entrada): array
{
    $cliente = trim((string) ($entrada['cliente'] ?? ''));
    $item    = (string) ($entrada['item'] ?? '');

    if ($cliente === '' || $item === '') {
        erro('Preencha todos os campos.');
    }

    if (mb_strlen($cliente) > 100) {
        erro('O nome do cliente deve ter no máximo 100 caracteres.');
    }

    if (!in_array($item, OFERTAS, true)) {
        erro('Oferta inválida.');
    }

    return [$cliente, $item];
}

try {
    $pdo    = conectar();
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        $linhas = $pdo->query('SELECT * FROM reservas ORDER BY id DESC')->fetchAll();

        responder([
            'ok'       => true,
            'reservas' => array_map('formatarReserva', $linhas),
        ]);
    }

    if ($metodo !== 'POST') {
        erro('Método não permitido.', 405);
    }

    $entrada = json_decode(file_get_contents('php://input'), true);

    if (!is_array($entrada)) {
        erro('Requisição inválida.');
    }

    $acao = (string) ($entrada['acao'] ?? '');

    switch ($acao) {

        case 'criar':
            [$cliente, $item] = validarCampos($entrada);
            $codigo = gerarCodigo($pdo);

            $stmt = $pdo->prepare('
                INSERT INTO reservas (codigo, cliente, item, status, criado_em)
                VALUES (:codigo, :cliente, :item, :status, :criado_em)
            ');
            $stmt->execute([
                ':codigo'    => $codigo,
                ':cliente'   => $cliente,
                ':item'      => $item,
                ':status'    => STATUS_PENDENTE,
                ':criado_em' => date('Y-m-d H:i:s'),
            ]);

            responder(['ok' => true, 'codigo' => $codigo], 201);

        case 'alterar':
            [$cliente, $item] = validarCampos($entrada);
            $reserva = buscarReserva($pdo, $entrada['id'] ?? 0);

            if (!$reserva) {
                erro('Reserva não encontrada.', 404);
            }

            if ($reserva['status'] !== STATUS_PENDENTE) {
                erro('Somente reservas pendentes podem ser alteradas.', 409);
            }

            $stmt = $pdo->prepare('UPDATE reservas SET cliente = :cliente, item = :item WHERE id = :id');
            $stmt->execute([
                ':cliente' => $cliente,
                ':item'    => $item,
                ':id'      => $reserva['id'],
            ]);

            responder(['ok' => true]);

        case 'validar':
            $reserva = buscarReserva($pdo, $entrada['id'] ?? 0);

            if (!$reserva) {
                erro('Reserva não encontrada.', 404);
            }

            if ($reserva['status'] !== STATUS_PENDENTE) {
                erro('Somente reservas pendentes podem ser validadas.', 409);
            }

            $codigoDigitado = strtoupper(trim((string) ($entrada['codigo'] ?? '')));

            if (!hash_equals($reserva['codigo'], $codigoDigitado)) {
                erro('Código de resgate inválido.', 422);
            }

            $stmt = $pdo->prepare('UPDATE reservas SET status = :status WHERE id = :id');
            $stmt->execute([':status' => STATUS_CONCLUIDO, ':id' => $reserva['id']]);

            responder(['ok' => true]);

        case 'cancelar':
            $reserva = buscarReserva($pdo, $entrada['id'] ?? 0);

            if (!$reserva) {
                erro('Reserva não encontrada.', 404);
            }

            if ($reserva['status'] !== STATUS_PENDENTE) {
                erro('Somente reservas pendentes podem ser canceladas.', 409);
            }

            $stmt = $pdo->prepare('UPDATE reservas SET status = :status WHERE id = :id');
            $stmt->execute([':status' => STATUS_CANCELADO, ':id' => $reserva['id']]);

            responder(['ok' => true]);

        default:
            erro('Ação desconhecida.');
    }
} catch (Throwable $e) {
    error_log('[CRUD4] ' . $e->getMessage());
    erro('Erro interno no servidor.', 500);
}
