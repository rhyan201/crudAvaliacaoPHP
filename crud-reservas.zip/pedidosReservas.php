<?php
require __DIR__ . '/db.php';
conectar();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>EcoWaste - Pedidos / Reservas</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

        :root {
            --verde-escuro: #1e5d3a;
            --verde-medio: #468b5d;
            --verde-claro: #dff5e6;
            --texto: #1f3329;
            --branco: #ffffff;
            --borda: #dfeae1;
            --sombra: rgba(30, 93, 58, 0.13);

            --vermelho: #b84242;
            --vermelho-claro: #fde8e8;

            --amarelo: #a47716;
            --amarelo-claro: #fff5d9;
        }

        * {
            box-sizing: border-box;
        }

        html {
            min-height: 100%;
        }

        body {
            min-height: 100vh;
            max-width: 1100px;
            margin: 0 auto;
            padding: 44px 24px 56px;

            font-family: 'Poppins', sans-serif;
            color: var(--texto);

            background:
                radial-gradient(
                    circle at top left,
                    rgba(143, 209, 141, 0.22),
                    transparent 25%
                ),
                radial-gradient(
                    circle at bottom right,
                    rgba(219, 191, 145, 0.18),
                    transparent 30%
                ),
                linear-gradient(
                    135deg,
                    #f9f7f1 0%,
                    #f3f9f2 32%,
                    #ecf8ef 100%
                );
        }

        h1,
        h2,
        p {
            margin-top: 0;
        }

        h1 {
            margin-bottom: 10px;
            color: var(--verde-escuro);
            font-size: clamp(2rem, 4vw, 3rem);
            text-align: center;
        }

        .desc {
            max-width: 650px;
            margin: 0 auto 36px;
            color: #587061;
            text-align: center;
        }

        h2 {
            margin-bottom: 18px;
            color: var(--verde-escuro);
            font-size: 1.35rem;
        }

        h2:nth-of-type(2) {
            margin-top: 48px;
        }

        label {
            display: block;
            margin: 16px 0 8px;
            font-weight: 600;
        }

        input,
        select {
            display: block;
            width: min(620px, 100%);

            padding: 13px 14px;

            border: 1.5px solid var(--borda);
            border-radius: 14px;

            outline: none;

            background: rgba(255, 255, 255, 0.86);
            color: var(--texto);

            font: inherit;

            transition:
                border-color 0.2s ease,
                box-shadow 0.2s ease;
        }

        input:focus,
        select:focus {
            border-color: rgba(30, 93, 58, 0.7);

            box-shadow:
                0 0 0 4px rgba(70, 139, 93, 0.1);
        }

        button {
            border: 0;
            border-radius: 14px;

            font-family: 'Poppins', sans-serif;
            font-weight: 700;

            cursor: pointer;

            transition:
                transform 0.2s ease,
                box-shadow 0.2s ease,
                opacity 0.2s ease;
        }

        button:hover {
            transform: translateY(-1px);
        }

        button:active {
            transform: translateY(0);
        }

        .botao-principal {
            margin-top: 22px;
            padding: 13px 20px;

            background:
                linear-gradient(
                    135deg,
                    var(--verde-medio),
                    var(--verde-escuro)
                );

            color: var(--branco);

            box-shadow:
                0 12px 22px rgba(30, 93, 58, 0.18);
        }

        .botao-principal:hover {
            box-shadow:
                0 16px 26px rgba(30, 93, 58, 0.2);
        }

        .botao-alterar-cancelar {
            margin-left: 8px;
            padding: 13px 20px;

            background: #eeeeee;
            color: #555555;
        }

        #mensagem {
            display: none;

            width: min(620px, 100%);

            margin-top: 18px;
            padding: 12px 16px;

            border-radius: 12px;

            background: var(--verde-claro);
            color: var(--verde-escuro);

            font-size: 0.9rem;
            font-weight: 600;
        }

        table {
            width: 100%;

            border-collapse: separate;
            border-spacing: 0;

            overflow: hidden;

            border: 1px solid rgba(30, 93, 58, 0.08);
            border-radius: 18px;

            background: rgba(255, 255, 255, 0.78);

            box-shadow:
                0 20px 50px var(--sombra);
        }

        th,
        td {
            padding: 15px 16px;

            border-bottom: 1px solid var(--borda);

            text-align: left;
        }

        th {
            background: var(--verde-escuro);
            color: var(--branco);

            font-size: 0.9rem;
            font-weight: 600;
        }

        td {
            background: rgba(255, 255, 255, 0.58);
            font-size: 0.9rem;
        }

        tr:last-child td {
            border-bottom: 0;
        }

        .codigo {
            display: inline-block;

            padding: 5px 9px;

            border-radius: 8px;

            background: var(--verde-claro);
            color: var(--verde-escuro);

            font-size: 0.8rem;
            font-weight: 700;
        }

        .status {
            display: inline-block;

            padding: 5px 10px;

            border-radius: 20px;

            font-size: 0.78rem;
            font-weight: 600;
        }

        .pendente {
            background: var(--amarelo-claro);
            color: var(--amarelo);
        }

        .concluido {
            background: var(--verde-claro);
            color: var(--verde-escuro);
        }

        .cancelado {
            background: var(--vermelho-claro);
            color: var(--vermelho);
        }

        .acoes {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        td button {
            margin: 0;
            padding: 9px 12px;
            border-radius: 10px;
            font-size: 0.82rem;
        }

        .botao-concluir {
            background: var(--verde-medio);
            color: var(--branco);
        }

        .botao-alterar {
            background: #e8f1eb;
            color: var(--verde-escuro);
        }

        .botao-cancelar {
            background: var(--vermelho-claro);
            color: var(--vermelho);
        }

        .botao-concluir:hover,
        .botao-alterar:hover,
        .botao-cancelar:hover {
            opacity: 0.88;
        }

        .vazio {
            padding: 30px;
            color: #718579;
            text-align: center;
            font-style: italic;
        }

        @media (max-width: 700px) {

            body {
                padding: 30px 16px 40px;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            th,
            td {
                padding: 12px;
            }

            .acoes {
                flex-wrap: nowrap;
            }

            .botao-alterar-cancelar {
                margin-left: 4px;
            }
        }
    </style>
</head>

<body>

    <h1>Pedidos / Reservas</h1>

    <p class="desc">
        Registre e acompanhe os resgates das ofertas realizados pelos clientes.
    </p>

    <h2 id="tituloFormulario">Nova Reserva</h2>

    <label for="cliente">
        Nome do cliente
    </label>

    <input
        type="text"
        id="cliente"
        placeholder="Digite o nome do cliente"
        autocomplete="off"
    >

    <label for="item">
        Oferta / Item
    </label>

    <select id="item">

        <option value="">
            Selecione uma oferta
        </option>

        <?php foreach (OFERTAS as $oferta): ?>
            <option value="<?= htmlspecialchars($oferta, ENT_QUOTES, 'UTF-8') ?>">
                <?= htmlspecialchars($oferta, ENT_QUOTES, 'UTF-8') ?>
            </option>
        <?php endforeach; ?>

    </select>

    <button
        type="button"
        id="botaoFormulario"
        class="botao-principal"
        onclick="criarReserva()"
    >
        Criar Reserva
    </button>

    <button
        type="button"
        id="botaoCancelarEdicao"
        class="botao-alterar-cancelar"
        onclick="cancelarEdicao()"
        style="display: none;"
    >
        Cancelar Edição
    </button>

    <div id="mensagem"></div>

    <h2>Histórico de Pedidos / Reservas</h2>

    <table>

        <thead>

            <tr>
                <th>Código</th>
                <th>Cliente</th>
                <th>Oferta</th>
                <th>Data</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>

        </thead>

        <tbody id="listaReservas"></tbody>

    </table>

    <script src="script.js"></script>

</body>

</html>
