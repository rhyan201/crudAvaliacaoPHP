<?php
declare(strict_types=1);

date_default_timezone_set('America/Sao_Paulo');

const OFERTAS = ['Maçã', 'Banana', 'Laranja', 'Cenoura', 'Tomate'];

const STATUS_PENDENTE  = 'Pendente';
const STATUS_CONCLUIDO = 'Concluído';
const STATUS_CANCELADO = 'Cancelado';

function conectar(): PDO
{
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $pasta = __DIR__ . '/dados';

    if (!is_dir($pasta)) {
        mkdir($pasta, 0775, true);
    }

    $pdo = new PDO('sqlite:' . $pasta . '/ecowaste.sqlite');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS reservas (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo    TEXT NOT NULL UNIQUE,
            cliente   TEXT NOT NULL,
            item      TEXT NOT NULL,
            status    TEXT NOT NULL DEFAULT 'Pendente'
                      CHECK (status IN ('Pendente', 'Concluído', 'Cancelado')),
            criado_em TEXT NOT NULL
        )
    ");

    return $pdo;
}
