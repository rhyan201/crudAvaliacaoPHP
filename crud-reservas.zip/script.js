const API = "api.php";

let idReservaEditando = null;
let reservas = [];

async function requisicao(corpo) {
    const opcoes = corpo
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(corpo)
        }
        : {};

    let resposta;

    try {
        resposta = await fetch(API, opcoes);
    } catch (erro) {
        throw new Error(
            "Não foi possível conectar ao servidor. " +
            "Abra a página por um servidor PHP (ex.: php -S localhost:8000)."
        );
    }

    let dados;

    try {
        dados = await resposta.json();
    } catch (erro) {
        throw new Error("Resposta inválida do servidor.");
    }

    if (!resposta.ok || !dados.ok) {
        throw new Error(dados.erro || "Erro ao comunicar com o servidor.");
    }

    return dados;
}

async function carregarReservas() {
    try {
        const dados = await requisicao();
        reservas = dados.reservas;
        atualizarTabela();
    } catch (erro) {
        console.error("Erro ao carregar reservas:", erro);
        alert(erro.message);
    }
}

async function criarReserva() {
    const campoCliente = document.getElementById("cliente");
    const campoItem = document.getElementById("item");

    const cliente = campoCliente.value.trim();
    const item = campoItem.value;

    if (cliente === "" || item === "") {
        alert("Preencha todos os campos.");
        return;
    }

    try {
        if (idReservaEditando !== null) {
            await requisicao({
                acao: "alterar",
                id: idReservaEditando,
                cliente: cliente,
                item: item
            });

            cancelarEdicao();
            await carregarReservas();
            mostrarMensagem("Reserva alterada com sucesso!");
            return;
        }

        const dados = await requisicao({
            acao: "criar",
            cliente: cliente,
            item: item
        });

        campoCliente.value = "";
        campoItem.value = "";

        await carregarReservas();

        mostrarMensagem(
            "Reserva criada com sucesso! Código: " + dados.codigo
        );
    } catch (erro) {
        alert(erro.message);
    }
}

function alterarReserva(id) {
    const reserva = encontrarReserva(id);

    if (!reserva) {
        return;
    }

    if (reserva.status !== "Pendente") {
        alert("Somente reservas pendentes podem ser alteradas.");
        return;
    }

    idReservaEditando = id;

    document.getElementById("cliente").value = reserva.cliente;
    document.getElementById("item").value = reserva.item;

    document.getElementById("tituloFormulario").textContent = "Alterar Reserva";
    document.getElementById("botaoFormulario").textContent = "Salvar Alterações";
    document.getElementById("botaoCancelarEdicao").style.display = "inline-block";

    window.scrollTo({ top: 0, behavior: "smooth" });
}

function cancelarEdicao() {
    idReservaEditando = null;

    document.getElementById("cliente").value = "";
    document.getElementById("item").value = "";

    document.getElementById("tituloFormulario").textContent = "Nova Reserva";
    document.getElementById("botaoFormulario").textContent = "Criar Reserva";
    document.getElementById("botaoCancelarEdicao").style.display = "none";
}

async function concluirReserva(id) {
    const reserva = encontrarReserva(id);

    if (!reserva) {
        return;
    }

    const codigoDigitado = prompt(
        "Digite o código de resgate para validar:",
        ""
    );

    if (codigoDigitado === null) {
        return;
    }

    try {
        await requisicao({
            acao: "validar",
            id: id,
            codigo: codigoDigitado.trim().toUpperCase()
        });

        await carregarReservas();
        mostrarMensagem("Código validado! Pedido concluído.");
    } catch (erro) {
        alert(erro.message);
    }
}

async function cancelarReserva(id) {
    const reserva = encontrarReserva(id);

    if (!reserva) {
        return;
    }

    if (!confirm("Deseja realmente cancelar esta reserva?")) {
        return;
    }

    try {
        await requisicao({ acao: "cancelar", id: id });

        if (idReservaEditando === id) {
            cancelarEdicao();
        }

        await carregarReservas();
        mostrarMensagem("Reserva cancelada com sucesso.");
    } catch (erro) {
        alert(erro.message);
    }
}

function atualizarTabela() {
    const lista = document.getElementById("listaReservas");

    if (reservas.length === 0) {
        lista.innerHTML = `
            <tr>
                <td colspan="6" class="vazio">
                    Nenhuma reserva cadastrada.
                </td>
            </tr>
        `;

        return;
    }

    lista.innerHTML = reservas.map(function (reserva) {
        return `
            <tr>
                <td>
                    <span class="codigo">${escaparHTML(reserva.codigo)}</span>
                </td>

                <td>${escaparHTML(reserva.cliente)}</td>

                <td>${escaparHTML(reserva.item)}</td>

                <td>${escaparHTML(reserva.data)}</td>

                <td>
                    <span class="status ${obterClasseStatus(reserva.status)}">
                        ${escaparHTML(reserva.status)}
                    </span>
                </td>

                <td>
                    <div class="acoes">
                        ${criarBotoesAcoes(reserva)}
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

function obterClasseStatus(status) {
    switch (status) {
        case "Pendente":
            return "pendente";

        case "Concluído":
            return "concluido";

        case "Cancelado":
            return "cancelado";

        default:
            return "";
    }
}

function criarBotoesAcoes(reserva) {
    if (reserva.status !== "Pendente") {
        return "";
    }

    return `
        <button
            type="button"
            class="botao botao-alterar"
            onclick="alterarReserva(${reserva.id})"
        >
            Alterar
        </button>

        <button
            type="button"
            class="botao botao-concluir"
            onclick="concluirReserva(${reserva.id})"
        >
            Validar Código
        </button>

        <button
            type="button"
            class="botao botao-cancelar"
            onclick="cancelarReserva(${reserva.id})"
        >
            Cancelar
        </button>
    `;
}

function encontrarReserva(id) {
    return reservas.find(function (reserva) {
        return reserva.id === id;
    });
}

function mostrarMensagem(texto) {
    const mensagem = document.getElementById("mensagem");

    if (!mensagem) {
        return;
    }

    mensagem.textContent = texto;
    mensagem.style.display = "block";

    setTimeout(function () {
        mensagem.style.display = "none";
    }, 4000);
}

function escaparHTML(valor) {
    const elemento = document.createElement("div");
    elemento.textContent = String(valor ?? "");
    return elemento.innerHTML;
}

carregarReservas();
