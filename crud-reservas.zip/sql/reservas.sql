CREATE DATABASE IF NOT EXISTS crud_reservas
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE crud_reservas;

DROP TABLE IF EXISTS reserva;

CREATE TABLE reserva (
    id_reserva    INT AUTO_INCREMENT PRIMARY KEY,
    codigo        VARCHAR(10)   NOT NULL UNIQUE,     -- código de resgate no formato RES-XXXXXX
    cliente       VARCHAR(100)  NOT NULL,
    item          VARCHAR(50)   NOT NULL,            -- oferta reservada (validada na API)
    status        ENUM('pendente', 'concluido', 'cancelado') NOT NULL DEFAULT 'pendente',
    data_criacao  DATETIME      DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO reserva (codigo, cliente, item, status) VALUES
('RES-7K2M9Q', 'Matheus',  'Maçã',   'pendente'),
('RES-X4B8TD', 'Carlos',   'Banana', 'concluido'),
('RES-3NP5ZA', 'Beatriz',  'Tomate', 'cancelado');
